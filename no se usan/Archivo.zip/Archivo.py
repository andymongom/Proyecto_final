import pygame
import sys
from Button import Button
import random
import math


pygame.init()

SCREEN = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Menu")
pygame.display.set_caption("Space Invaders")
icon = pygame.image.load("icons8-star-wars-naboo-ship-64.png")
pygame.display.set_icon(icon)
BG = pygame.image.load("pexels-francesco-ungaro-998641.jpg")


def get_font(size):
    return pygame.font.Font("assets/font.ttf", size)


new_username = ""
score = 0


def add_new_user():
    global new_username
    base_font = pygame.font.Font(None, 45)

    while True:
        SCREEN.blit(BG, (0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    print("New Username:", new_username)
                    with open("HitorialJUEGO", "a") as file:
                        file.write(f"{new_username}\n")
                    return
                elif event.key == pygame.K_BACKSPACE:
                    new_username = new_username[:-1]
                else:
                    new_username += event.unicode

        text_surface = base_font.render("Enter username: " + new_username, True, (255, 255, 255))

        SCREEN.blit(text_surface, (260, 200))

        pygame.display.update()


def niveles_meteoritos():

    # Player variables
    img_player = pygame.image.load("icons8-star-wars-naboo-ship-64.png")
    player_x = 368  # 400 - 32 para que quede centrado
    player_y = 536  # 600- 64 para que quede centrado
    player_x_change = 0

    # Enemy variables
    img_enemy = []
    enemy_x = []
    enemy_y = []
    enemy_x_change = []
    enemy_y_change = []
    number_of_enemies = 10
    for i in range(number_of_enemies):
        img_enemy.append(pygame.image.load("icons8-star-trek-romulan-ship-64.png"))
        enemy_x.append(random.randint(0, 736))
        enemy_y.append(random.randint(30, 200))
        enemy_x_change.append(2.7)
        enemy_y_change.append(1.8)

    # Bullet variables
    img_bullet = pygame.image.load("icons8-rayo-láser-32.png")
    bullet_x = 0
    bullet_y = 490
    bullet_x_change = 0
    bullet_y_change = 15
    bullet_visible = False

    # Score Variables
    score = 0
    score_font = pygame.font.Font("freesansbold.ttf", 32)
    score_text_x = 10
    score_text_y = 10

    # Level Variable
    nivel = 1

    # Meteor variables
    img_meteorito = pygame.image.load("asteroid_98597.png")
    meteorito_x = []
    meteorito_y = []
    meteorito_visible = False

    # Show score
    def show_score(x, y):
        text = score_font.render(f"Score: {score}", True, (255, 255, 255))
        SCREEN.blit(text, (x, y))

    # Show level
    def show_level(x, y):
        level_text = score_font.render(f"Level: {nivel}", True, (255, 255, 255))
        SCREEN.blit(level_text, (x, y + 50))

    # Show meteoritos
    def show_meteoritos():
        if meteorito_visible:
            for i in range(len(meteorito_x)):
                meteorito_y[i] += 5  # Ajusta la velocidad de caída de los meteoritos
                SCREEN.blit(img_meteorito, (meteorito_x[i], meteorito_y[i]))
                if meteorito_y[i] > 600:
                    # Eliminar el meteorito si sale de la pantalla
                    meteorito_x.pop(i)
                    meteorito_y.pop(i)
                    break

    # Show player in screen
    def player(x, y):
        SCREEN.blit(img_player, (x, y))

    # Show enemy
    def enemy(x, y, enemy_index):
        SCREEN.blit(img_enemy[enemy_index], (x, y))

    # Shoot Bullet
    def shoot_bullet(x, y):
        nonlocal bullet_visible
        bullet_visible = True
        SCREEN.blit(img_bullet, (x + 16, y + 10))

    # Detect collision
    def detect_collision(x_1, y_1, x_2, y_2):
        x_sub = x_2 - x_1
        y_sub = y_2 - y_1
        distance = math.sqrt(math.pow(x_sub, 2) + math.pow(y_sub, 2))
        if distance < 27:
            return True

    # Game loop
    is_running = True
    while is_running:
        # Image background
        # screen.fill((37, 40, 80))
        SCREEN.blit(BG, (0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                is_running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    player_x_change -= 7.0
                if event.key == pygame.K_RIGHT:
                    player_x_change += 7.0
                if event.key == pygame.K_SPACE:
                    if not bullet_visible:
                        bullet_x = player_x
                    shoot_bullet(bullet_x, bullet_y)
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or pygame.K_RIGHT:
                    player_x_change = 0

        # Update player location
        player_x += player_x_change

        # Keep player inside the screen
        if player_x <= 0:
            player_x = 0
        elif player_x >= 736:
            player_x = 736

        for i in range(number_of_enemies):
            # Update enemy location
            enemy_x[i] += enemy_x_change[i]

            # Keep enemies inside the screen
            if enemy_x[i] <= 0:
                enemy_x_change[i] += 0.3
                enemy_y[i] += enemy_y_change[i]
            elif enemy_x[i] >= 736:
                enemy_x_change[i] -= 0.3
                enemy_y[i] += enemy_y_change[i]

            # Detect collision
            collision = detect_collision(enemy_x[i], enemy_y[i], bullet_x, bullet_y)
            if collision:
                enemy_x[i] = random.randint(0, 736)
                enemy_y[i] = random.randint(30, 200)
                bullet_visible = False
                score += 1
                bullet_y = 500
                if score % 10 == 0:
                    nivel += 1
                    for j in range(number_of_enemies):
                        enemy_x_change[j] += 1.0
                if score == 30 and not meteorito_visible:
                    meteorito_visible = True
                    # Crear 5 meteoritos y asignar sus coordenadas iniciales
                    for j in range(10):
                        meteorito_x.append(random.randint(50, 750))
                        meteorito_y.append(random.randint(-200, -50))

            # Show enemy
            enemy(enemy_x[i], enemy_y[i], i)

        # Shoot bullet
        if bullet_y <= -64:
            bullet_y = 500
            bullet_visible = False
        if bullet_visible:
            shoot_bullet(bullet_x, bullet_y)
            bullet_y -= bullet_y_change

        # Show player
        player(player_x, player_y)

        # Show score
        show_score(score_text_x, score_text_y)

        # Show level
        show_level(score_text_x, score_text_y)

        # Show meteoritos
        show_meteoritos()

        with open("HitorialJUEGO", "a") as file:
            file.write(f"{nivel}\n")
            file.write(f'{score}\n')
            file.write("\n")
        # Update screen
        pygame.display.update()


def scoreboard():
    file_path = "HitorialJUEGO"
    with open(file_path, "r") as file:
        text_content = file.readlines()

    font_size = 25
    font = pygame.font.Font(None, font_size)

    line_height = font.get_linesize()
    y = 50 + line_height  # Posición vertical inicial

    while True:
        scoreboard_MOUSE_POS = pygame.mouse.get_pos()

        SCREEN.fill("white")

        scoreboard_TEXT = font.render("This is the scoreboard history", True, "Black")
        SCREEN.blit(scoreboard_TEXT, (28, 50))

        for line in text_content:
            text_surface = font.render(line.strip(), True, (0, 0, 0))
            text_rect = text_surface.get_rect()
            text_rect.topleft = (28, y)
            SCREEN.blit(text_surface, text_rect)
            y += line_height  # Actualizar la posición vertical

        y = 50 + line_height  # Restablecer la posición vertical

        scoreboard_BACK = Button(pos=(640, 530),
                                 text_input="BACK", font=get_font(75), base_color="Black", hovering_color="Green")

        scoreboard_BACK.changeColor(scoreboard_MOUSE_POS)
        scoreboard_BACK.update(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if scoreboard_BACK.checkForInput(scoreboard_MOUSE_POS):
                    main_menu()

        pygame.display.update()


def credits():
    while True:
        credits_MOUSE_POS = pygame.mouse.get_pos()

        SCREEN.fill("white")

        credits_TEXT = get_font(45).render("Andy", True, "Black")
        credits_TEXT2 = get_font(45).render("Fer", True, "Black")
        credits_TEXT3 = get_font(45).render("Lucia", True, "Black")
        SCREEN.blit(credits_TEXT, (640 - credits_TEXT.get_width() // 2, 100 - credits_TEXT.get_height() // 2))
        SCREEN.blit(credits_TEXT2, (640 - credits_TEXT.get_width() // 2, 170 - credits_TEXT.get_height() // 2))
        SCREEN.blit(credits_TEXT3, (640 - credits_TEXT.get_width() // 2, 240 - credits_TEXT.get_height() // 2))

        credtis_BACK = Button(pos=(640, 530),
                              text_input="BACK", font=get_font(75), base_color="Black", hovering_color="Green")

        credtis_BACK.changeColor(credits_MOUSE_POS)
        credtis_BACK.update(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if credtis_BACK.checkForInput(credits_MOUSE_POS):
                    main_menu()

        pygame.display.update()


def main_menu():
    while True:
        SCREEN.blit(BG, (0, 0))

        MENU_MOUSE_POS = pygame.mouse.get_pos()

        MENU_TEXT = get_font(75).render("MAIN MENU", True, "#b68f40")
        MENU_POS = (420 - MENU_TEXT.get_width() // 2, 100 - MENU_TEXT.get_height() // 2)

        PLAY_BUTTON = Button(pos=(400, 200),
                             text_input="PLAY", font=get_font(40), base_color="#d7fcd4",
                             hovering_color="#b68f40")
        scoreboard_BUTTON = Button(pos=(420, 300),
                                   text_input="SCOREBOARD", font=get_font(40), base_color="#d7fcd4",
                                   hovering_color="#b68f40")
        credits_BUTTON = Button(pos=(400, 400),
                                text_input="CREDITS", font=get_font(45), base_color="#d7fcd4",
                                hovering_color="#b68f40")
        QUIT_BUTTON = Button(pos=(400, 500),
                             text_input="QUIT", font=get_font(40), base_color="#d7fcd4",
                             hovering_color="#cb3234")

        SCREEN.blit(MENU_TEXT, MENU_POS)

        for button in [PLAY_BUTTON, scoreboard_BUTTON, credits_BUTTON, QUIT_BUTTON]:
            button.changeColor(MENU_MOUSE_POS)
            button.update(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BUTTON.checkForInput(MENU_MOUSE_POS):
                    add_new_user()
                    niveles_meteoritos()
                if scoreboard_BUTTON.checkForInput(MENU_MOUSE_POS):
                    scoreboard()
                if credits_BUTTON.checkForInput(MENU_MOUSE_POS):
                    credits()
                if QUIT_BUTTON.checkForInput(MENU_MOUSE_POS):
                    pygame.quit()
                    sys.exit()

        pygame.display.update()


main_menu()
